package applab;

public class ui {

}
