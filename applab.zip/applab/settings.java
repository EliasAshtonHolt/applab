package applab;

public class settings {

}