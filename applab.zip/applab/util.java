package applab;

public class util {

}
