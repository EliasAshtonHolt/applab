package applab;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.DataFlavor;
import java.io.*;
import java.util.List;

public class Main {

    private File droppedFile;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main());
    }

    public Main() {

        JFrame frame = new JFrame("AppLab - Auto JAR Builder");
        frame.setSize(900, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JLabel status = new JLabel("Drop a .java file here", SwingConstants.CENTER);
        status.setFont(new Font("Segoe UI", Font.BOLD, 22));

        JButton buildBtn = new JButton("Build JAR");
        buildBtn.setFont(new Font("Segoe UI", Font.BOLD, 18));

        buildBtn.addActionListener(e -> {
            if (droppedFile == null) {
                JOptionPane.showMessageDialog(frame, "Drop a .java file first!");
                return;
            }
            buildJar(frame, droppedFile);
        });

        JPanel bottom = new JPanel();
        bottom.add(buildBtn);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(status, BorderLayout.CENTER);
        panel.add(bottom, BorderLayout.SOUTH);

        // Drag & drop
        panel.setTransferHandler(new TransferHandler() {
            @Override
            public boolean canImport(TransferSupport support) {
                return support.isDataFlavorSupported(DataFlavor.javaFileListFlavor);
            }

            @Override
            public boolean importData(TransferSupport support) {
                try {
                    List<File> files = (List<File>) support.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);

                    droppedFile = files.get(0);
                    status.setText("Loaded: " + droppedFile.getName());

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
                return true;
            }
        });

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    private void buildJar(JFrame frame, File javaFile) {
        try {
            File dir = javaFile.getParentFile();

            statusPopup(frame, "Compiling...");

            // 1. Compile
            Process compile = new ProcessBuilder(
                    "javac",
                    javaFile.getName()
            )
                    .directory(dir)
                    .start();

            compile.waitFor();

            String className = javaFile.getName().replace(".java", ".class");

            File classFile = new File(dir, className);

            if (!classFile.exists()) {
                JOptionPane.showMessageDialog(frame, "Compile failed!");
                return;
            }

            // 2. Create JAR
            statusPopup(frame, "Creating JAR...");

            String jarName = javaFile.getName().replace(".java", ".jar");

            Process jar = new ProcessBuilder(
                    "jar",
                    "cf",
                    jarName,
                    className
            )
                    .directory(dir)
                    .start();

            jar.waitFor();

            JOptionPane.showMessageDialog(frame,
                    "JAR created!\nLocation:\n" + new File(dir, jarName).getAbsolutePath());

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Error: " + e.getMessage());
        }
    }

    private void statusPopup(JFrame frame, String text) {
        frame.setTitle("AppLab - " + text);
    }
}