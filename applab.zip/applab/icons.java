package applab;

public class icons {

}
